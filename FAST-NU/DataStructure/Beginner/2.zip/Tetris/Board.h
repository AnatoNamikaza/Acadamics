#include "Piece.h"

class Board: public Piece {

private:

    box **board;

public:

    Board() {
        board = new box *[20];
        for (int i = 0; i < 20; i++)
            board[i] = new box[10];
        for (int i = 0; i < 19; i++)
            for (int j = 0; j < 10; j++)
                board[i][j].SetDown(&board[i + 1][j]), board[i + 1][j].SetUp(&board[i][j]);
        for (int i = 0; i < 20; i++)
            for (int j = 0; j < 9; j++)
                board[i][j].SetRight(&board[i][j + 1]), board[i][j + 1].SetLeft(&board[i][j]);
    }

    void LineDetected() {
        for (int i = 19; i >= 0; i--) {
            bool detect = true;
            for (int j = 0; j < 10; j++) {
                if (board[i][j].GetBoxColor() == 0) {
                    detect = false;
                    break;
                }
            }
            if (detect)
                Rearrange(i);
        }
    }

    void Rearrange(int row) {
        for (int i = row; i > 0; i--)
            for (int j = 0; j < 10; j++)
                board[i][j].SetBoxColor(board[i - 1][j].GetBoxColor());
        for (int j = 0; j < 10; j++)
            board[0][j].SetBoxColor(0);
    }

    box *GetCoordinateBox(int row, int col) { return &board[row][col]; };

    void PrintBoard() {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 10; j++) {
                std::cout << board[i][j].GetBoxColor() << ' ';
            }
            std::cout << '\n';
        }
        std::cout << std::endl;
    }

    ~Board() {
        for (int i = 0; i < 20; i++)
            delete[] board[i], board[i] = nullptr;
        delete[] board, board = nullptr;
    }
};