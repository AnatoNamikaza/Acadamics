#include "Board.h"
#include <SFML/Graphics.hpp>
//#include <TimeChecker.h>

int main() {

    int arrangements[7][4][6] = {
            {{0, 4, 1, 2, 0, 0}, {0, 4, 1, 2, 0, 0}, {0, 4, 1, 2, 0, 0}, {0, 4, 1, 2, 0, 0}},
            {{0, 1, 1, 1, 0, 0}, {0, 2, 0, 4, 4, 0}, {0, 0, 1, 1, 1, 0}, {0, 0, 2, 0, 4, 4}},
            {{0, 3, 2, 0, 1, 0}, {0, 4, 0, 2, 1, 0}, {0, 3, 0, 1, 4, 0}, {0, 2, 0, 4, 3, 0}},
            {{0, 3, 0, 1, 2, 0}, {0, 2, 0, 4, 1, 0}, {0, 1, 0, 3, 4, 0}, {0, 4, 0, 2, 3, 0}},
            {{0, 3, 0, 2, 1, 0}, {0, 2, 0, 1, 4, 0}, {0, 1, 0, 4, 3, 0}, {0, 4, 0, 3, 2, 0}},
            {{0, 1, 0, 2, 0, 3}, {0, 1, 0, 2, 0, 4}, {0, 1, 0, 3, 0, 4}, {0, 2, 0, 3, 0, 4}},
            {{0, 1, 0, 2, 3, 0}, {0, 4, 0, 1, 2, 0}, {0, 3, 0, 4, 1, 0}, {0, 2, 0, 3, 4, 0}}
    };


//    TimeChecker chk;
    Board GameBoard;
    GameBoard.PrintBoard();
    box *b = GameBoard.GetCoordinateBox(16, 4);
    int a[6] = {0, 0, 0, 0, 0, 0};

    for (int i = 0; i < 7; i++)
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < 6; k++)
                a[k] = arrangements[i][j][k];
            Piece bo(b, 1, a);
            bo.CreatPiece();
            std::cout << "Piece: " << i << ", Formation: " << j << '\n';
            GameBoard.PrintBoard();
            bo.ClearPiece();
        }

//    b=GameBoard.GetCoordinateBox(19,6);
//    bo.SetStartBox(b);
//    bo.CreatPiece();
//    GameBoard.PrintBoard();
//
//    int c[]={0,4,1,2,0};
//    b=GameBoard.GetCoordinateBox(18,4);
//    bo.SetStartBox(b);
//    bo.SetDirections(c);
//    bo.CreatPiece();
//    GameBoard.PrintBoard();
//
//    GameBoard.LineDetected();
//    GameBoard.PrintBoard();

    return 0;
}