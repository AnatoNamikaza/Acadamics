#include <iostream>

class box {

private:

    int BoxColor;
    box *Right, *Left, *Up, *Down;

public:

    box(int color = 0, box *rbox = nullptr, box *lbox = nullptr, box *ubox = nullptr, box *dbox = nullptr) {
        BoxColor = color, Right = nullptr, Left = nullptr, Up = nullptr, Down = nullptr;
        if (rbox)
            Right = rbox;
        if (lbox)
            Left = lbox;
        if (ubox)
            Up = ubox;
        if (dbox)
            Down = dbox;
    }

    box(const box &obj) {
        BoxColor = 0, Right = nullptr, Left = nullptr, Up = nullptr, Down = nullptr;
        BoxColor = obj.GetBoxColor(), Right = obj.GetRight(), Left = obj.GetLeft(), Up = obj.GetUp(), Down = obj.GetDown();
    }

    box &operator=(const box &obj) {
        BoxColor = 0, Right = nullptr, Left = nullptr, Up = nullptr, Down = nullptr;
        BoxColor = obj.GetBoxColor(), Right = obj.GetRight(), Left = obj.GetLeft(), Up = obj.GetUp(), Down = obj.GetDown();
        return *this;
    }

    int GetBoxColor() const { return this->BoxColor; };

    box *GetRight() const { return this->Right; };

    box *GetLeft() const { return this->Left; };

    box *GetUp() const { return this->Up; };

    box *GetDown() const { return this->Down; };

    void SetBoxColor(int c) { this->BoxColor = c; };

    void SetRight(box *ptrbox) { this->Right = ptrbox; };

    void SetLeft(box *ptrbox) { this->Left = ptrbox; };

    void SetUp(box *ptrbox) { this->Up = ptrbox; };

    void SetDown(box *ptrbox) { this->Down = ptrbox; };

    ~box() { BoxColor = 0, Right = nullptr, Left = nullptr, Up = nullptr, Down = nullptr; }
};