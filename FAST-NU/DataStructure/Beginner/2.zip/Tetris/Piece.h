#include "Box.h"

class Piece: public box {

private:

    box *startBox;
    int PieceColor;
    int *directions;

public:

    Piece(box *Sbox = nullptr, int const Pcolor = 0, const int *arr = nullptr) {
        this->startBox = nullptr, this->PieceColor = 0, this->directions = new int[6]{0};
        if (Pcolor != 0)
            PieceColor = Pcolor;
        if (Sbox)
            startBox = Sbox;
        if (arr)
            for (int i = 0; i < 6; i++)
                directions[i] = arr[i];
    }

    void CreatPiece() {
        box *ref = this->startBox;
        for (int i = 0; i < 6; i++) {
            if (directions[i] == 0)
                ref = startBox;
            if (directions[i] == 1)
                ref = ref->GetRight();
            if (directions[i] == 2)
                ref = ref->GetUp();
            if (directions[i] == 3)
                ref = ref->GetLeft();
            if (directions[i] == 4)
                ref = ref->GetDown();
            ref->SetBoxColor(PieceColor);
        }
        ref = nullptr;
    }

    void ClearPiece() {
        box *ref = this->startBox;
        for (int i = 0; i < 6; i++) {
            if (directions[i] == 0)
                ref = startBox;
            if (directions[i] == 1)
                ref = ref->GetRight();
            if (directions[i] == 2)
                ref = ref->GetUp();
            if (directions[i] == 3)
                ref = ref->GetLeft();
            if (directions[i] == 4)
                ref = ref->GetDown();
            ref->SetBoxColor(0);
        }
        ref = nullptr;
    }

    box *GetStartBox() { return this->startBox; };

    void SetStartBox(box *sBox) { this->startBox = sBox; };

    void SetDirections(int *dir) {
        for (int i = 0; i < 6; i++)
            directions[i] = dir[i];
    };

    ~Piece() {
        this->startBox = nullptr, this->PieceColor = 0;
        delete[] directions, directions = nullptr;
    }
};