//Avishai Rostamian

#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <unistd.h>
#include <string.h>

struct sems
{
    sem_t binary_sem, produced, consumed;
};

int main(int argc, char** argv)
{

    int BUFFER_SIZE = atoi(argv[1]),
        CHUNK_SIZE = atoi(argv[2]);

    char inbuf[16];
    int shMemProducerCharCount = 0, shMemConsumerCharCount = 0;

    int n, fd[2];
    // The pipe is created and its file descriptors returned.
    if (pipe(fd) < 0) {
        fprintf(stderr, "Pipe failed");
            return 1;
    }

    //Creating shared memory region for semaphores struct
    int shmid = shmget(77, sizeof(struct sems), IPC_CREAT | 0666);
    if (shmid == -1)
    {
        fprintf(stderr, "SHM created failed!\n");
        return 1;
    }

    pid_t PID;
    PID = fork();

    // Child process
    if (PID == 0)
    {
        // wait(NULL);
        printf("\t[ I am a child process ]\n");
        printf("\tTrg_File = %s\n", argv[4]);
        FILE* fout = fopen(argv[4], "w");
        if (!fout)
        {
            perror("File not found / could not be opened!");
            return 1;
        }
        struct sems* semsSHM = shmat(shmid, NULL, 0);

        //Shared memory region for reading data read from file
        int shmid2 = shmget(78, BUFFER_SIZE, IPC_CREAT | 0666);
        char* buffer = shmat(shmid2, NULL, 0);

        for (;;)
        {
            sem_wait(&semsSHM->consumed);
            sem_wait(&semsSHM->binary_sem);
            //If $ is found in shared memory, print $ and break the loop.
            if (strcmp(buffer, "$") == 0)
            {
                close(fd[1]);
                int val = 0;
                printf("Read %s from shared memory\n", buffer);
                read(fd[0], &val, sizeof(val));
                close(fd[0]);
                sem_post(&semsSHM->produced);
                sem_post(&semsSHM->binary_sem);
                printf("CHILD: The producer value of shMemProducerCharCount = %d\n", val);
                printf("CHILD: The consumer value of shMemConsumerCharCount = %d\n", shMemConsumerCharCount);


                break;
            }
            else
            {
                printf("Read %s from shared memory\n", buffer);
                printf("-------------Press enter key to continue-------------");
                getchar();
            }
            fputs(buffer, fout);
            shMemConsumerCharCount = shMemConsumerCharCount + sizeof(buffer);
            sem_post(&semsSHM->produced);
            sem_post(&semsSHM->binary_sem);
            // printf("\nYes Child 5");
        }
        fclose(fout);
        //Detaching the attached pointers
        shmdt(semsSHM);
        shmdt(buffer);

        //Marking both shared memory regions for deletion
        shmctl(shmid2, IPC_RMID, NULL);
        shmctl(shmid, IPC_RMID, NULL);
    }
    else
    {
        printf("\t[ I am a parent process ]\n");
        printf("\tSrc_File = %s\n", argv[3]);


        struct sems* semsSHM = (struct sems*)shmat(shmid, NULL, 0);

        // Initializing semaphores
        sem_init(&semsSHM->binary_sem, 1, 1);
        sem_init(&semsSHM->produced, 1, 1);
        sem_init(&semsSHM->consumed, 1, 0);

        int BUFFER_SIZE = atoi(argv[1]), CHUNK_SIZE = atoi(argv[2]);

        FILE* fin = fopen(argv[3], "r");
        if (!fin)
        {
            perror("File not found / could not be opened!");
            return 1;
        }

        //Shared memory region for reading data read from file
        int shmid2 = shmget(78, BUFFER_SIZE, IPC_CREAT | 0666);
        if (shmid2 == -1)
        {
            fprintf(stderr, "SHM created failed!\n");
            return 1;
        }
        char* buffer = (char*)shmat(shmid2, NULL, 0);

        //Character array for storing data read from file
        char* data = (char*)malloc(CHUNK_SIZE * sizeof(char));

        //Variable for checking if EOF reached
        int exit = 0;

        for (; exit == 0;)
        {
            sem_wait(&semsSHM->produced);
            sem_wait(&semsSHM->binary_sem);

            int dataRead = fgets(data, CHUNK_SIZE, fin) ? 1 : 0;
            if (dataRead == 0)
            {
                close(fd[0]);
                strcpy(buffer, "$");
                write(fd[1], &shMemProducerCharCount, sizeof(shMemProducerCharCount));
                printf("\PARENT: The producer value of shMemProducerCharCount = %d\n", shMemProducerCharCount);
                close(fd[1]);

                exit = 1;
            }
            else
            {
                strcpy(buffer, data);
                printf("\Parent: IN = %s\n", buffer);
                printf("\Parent: ITEM = %s\n", data);
                shMemProducerCharCount = shMemProducerCharCount + sizeof(buffer);
            }
            sem_post(&semsSHM->binary_sem);
            sem_post(&semsSHM->consumed);
        }
        fclose(fin);
        wait(NULL);
        //Destroying all initialized semaphores
        sem_destroy(&semsSHM->binary_sem);
        sem_destroy(&semsSHM->produced);
        sem_destroy(&semsSHM->consumed);

        //Detaching the attached pointers
        shmdt(semsSHM);
        shmdt(buffer);

        //Marking both shared memory regions for deletion
        shmctl(shmid2, IPC_RMID, NULL);
        shmctl(shmid, IPC_RMID, NULL);
    }

    return 0;
}