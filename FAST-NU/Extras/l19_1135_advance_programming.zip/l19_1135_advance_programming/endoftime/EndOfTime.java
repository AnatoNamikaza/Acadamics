import java.util.Date;

public class EndOfTime{
    public static void main(String argv[]){
        Date date = new Date(System.currentTimeMillis());
	System.out.println(date);
    }
}
