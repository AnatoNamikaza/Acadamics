import java.util.Date;
import java.io.File;
import java.text.ParseException;
import java.time.*;
import java.time.ZoneOffset;

public class SetDate{
    public static void setDate(String date, String time, String fileName) throws
	IllegalArgumentException {
	//your code here
	String [] hour_min_sec = time.split(":");
	String [] year_month_date = date.split("/");
	LocalDateTime newLocalDateTime = LocalDateTime.of(Integer.parseInt(year_month_date[2]),Integer.parseInt(year_month_date[1]),Integer.parseInt(year_month_date[0]),Integer.parseInt(hour_min_sec[0]),Integer.parseInt(hour_min_sec[1]),Integer.parseInt(hour_min_sec[2]));
	Instant instant = newLocalDateTime.toInstant(ZoneOffset.UTC);
	File file = new File(fileName);
	file.setLastModified(instant.toEpochMilli());
    }
    public static void main(String[] argv){
	int argc = argv.length;
	if(argc < 3){
	    System.out.println("method to call: java Setdate 1/7/2020 13:05:55 filename");
	    System.exit(1);
	}
	else{
	    try{
		setDate(argv[0],argv[1],argv[2]);
		System.out.println("date updated successfully");	    
	    }
	    catch(Exception e){
		System.out.println(e);		
	    }
	}
    }
}
