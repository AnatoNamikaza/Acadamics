import intro2java.PersonViewer;

public class EnhancedPersonViewer extends PersonViewer{

    public void view(Object o){
	if(o instanceof Employee){
	    viewPerson((Employee)o);
	}
	else if(o instanceof Lecturer){
	    viewPerson((Lecturer)o);
	}
	else if(o instanceof Student){
	    viewPerson((Student)o);
	}
	else{
	    System.out.println("error: wrong type\n");
	}

    }
    public void viewPerson(Employee e){
	System.out.println(e.getDescription());
    }
    public void viewPerson(Lecturer l){
	System.out.println(l.getDescription());
	
    }
    public void viewPerson(Student s){
	System.out.println(s.getDescription());
	
    }

    public static void main(String argv[]){
	Student std1 = new Student("Cr abdul rehman","cr@gmail.com",'A');
	Lecturer lec1 = new Lecturer("Sir ghafoor","teacher@gmail.com","computer science");
	Employee emp1 = new Employee("Madam kanwal","kanwal@gmail.com","HS");
	EnhancedPersonViewer enhancedpersonViewer = new EnhancedPersonViewer();
	enhancedpersonViewer.view(std1);
        enhancedpersonViewer.view(lec1);
	enhancedpersonViewer.view(emp1);
    }
}
