import intro2java.PersonViewer;
public class PersonViewerTest{
    public static void main(String args[]){
	Student s1 = new Student("Zaeem","zaeemyousaf@live.com",'D');
	Lecturer l1 = new Lecturer("Ms Hira","hira@live.com","Adavanced Programming");
	Employee e1 = new Employee("Sir haroon","haroon@gmail.com","CS");
	PersonViewer personViewer = new PersonViewer();
	// view is a polymorphic function because person is interface which takes an abstract class
	// and creates runtime binding and ultimately provide polymorphism
	personViewer.view(s1);
	personViewer.view(l1);
	personViewer.view(e1);
    }
}
