import intro2java.Person;

public class Lecturer implements Person{

    private String email,name, subject;
    
    Lecturer(String _name,String _email, String _subject){
	name = _name;
	email = _email;
	subject = _subject;
    }
    public String getDescription(){
	String des = "teaches ";
	des = des + subject;
	return des;
    }

    public String getEmail(){
	return email;
    }

    public String getName(){
	return name;
    }
}
