import intro2java.Person;

public class Employee implements Person{

    private String email,name, department;
    
    Employee(String _name,String _email, String q_department){
	name = _name;
	email = _email;
	department = q_department;
    }
    public String getEmail(){
	return email;
    }
    public String getName(){
	return name;
    }

    public String getDepartment(){
	return department;
    }
    public String getDescription(){
	String des = name;
	des = des + " works in ";
	des = des + department;
	des = des + " department";
	return des;
    }
}
