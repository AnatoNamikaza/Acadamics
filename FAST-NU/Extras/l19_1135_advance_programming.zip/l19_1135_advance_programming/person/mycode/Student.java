import intro2java.Person;
public class Student implements Person{

    private String email,name;
    private char grade;
    
    Student(String _name,String _email, char _grade){
	name = _name;
	email = _email;
	grade = _grade;
    }
    public String getEmail(){
	return email;
    }
    public String getName(){
	return name;

    }
    public String getDescription(){
	String des = "a ";
	des = des + grade;
	des = des + " grade Student";
	return des;
    }
    public char getGrade(){
	return grade;
    }
}
