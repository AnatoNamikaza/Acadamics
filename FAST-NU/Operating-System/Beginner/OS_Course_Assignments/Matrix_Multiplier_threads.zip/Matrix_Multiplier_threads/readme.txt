All the code have been thoroughly tested on vs code and terminal.

Commands to use:

	g++ main.cpp -lpthread -o main.exe

	./main.exe 1.txt 2.txt
		or
	for executing with valgrind
	valgrind ./main.exe 1.txt 2.txt

Note: The execution time differs when using valgrind cause of additional work.
Its behaviour may vary on the hardware.

		Thank You :)