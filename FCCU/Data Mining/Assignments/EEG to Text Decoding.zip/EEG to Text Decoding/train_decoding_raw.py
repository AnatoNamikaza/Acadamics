import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import DataLoader
import pickle
import json
import time
from tqdm import tqdm
from transformers import BartTokenizer
from data_raw import ZuCo_dataset
from config import get_config
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Model Definitions for CNN, LSTM, and Random Forest
class CNNModel(nn.Module):
    def __init__(self, input_channels, num_classes):
        super(CNNModel, self).__init__()
        self.conv1 = nn.Conv1d(input_channels, 64, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv1d(64, 128, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool1d(2)
        self.fc1 = nn.Linear(128 * 16, 256)
        self.fc2 = nn.Linear(256, num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(x.size(0), -1)  # Flatten the tensor
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x


class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        out, (hn, cn) = self.lstm(x)
        out = self.fc(out[:, -1, :])  # Use the last output for classification
        return out

# Add a function to integrate Random Forest for EEG signal classification
def train_random_forest(train_data, train_labels):
    rf = RandomForestClassifier(n_estimators=100)
    rf.fit(train_data, train_labels)
    return rf

def evaluate_random_forest(model, test_data):
    predictions = model.predict(test_data)
    return predictions

def train_model(dataloaders, device, model, criterion, optimizer, scheduler, num_epochs=25, checkpoint_path_best='./checkpoints/decoding_raw/best/temp_decoding.pt', checkpoint_path_last='./checkpoints/decoding_raw/last/temp_decoding.pt', stepone=False):
    since = time.time()

    best_loss = float('inf')
    train_losses = []
    val_losses = []
    index_plot= 0
    index_plot_dev=0

    for epoch in range(num_epochs):
        print(f'Epoch {epoch}/{num_epochs - 1}')
        print(f"lr: {scheduler.get_lr()}")
        print('-' * 10)

        # Each epoch has a training and validation phase
        for phase in ['train', 'dev', 'test']:
            if phase == 'train':
                model.train()  # Set model to training mode
            else:
                model.eval()   # Set model to evaluate mode

            running_loss = 0.0
            target_tokens_list = []
            pred_tokens_list = []

            # Iterate over data.
            with tqdm(dataloaders[phase], unit="batch") as tepoch:
                for batch_idx, (_, seq_len, input_masks, input_mask_invert, target_ids, target_mask, sentiment_labels, sent_level_EEG, input_raw_embeddings, input_raw_embeddings_lengths, word_contents, word_contents_attn, subject_batch) in enumerate(tepoch):
                    input_embeddings_batch = input_raw_embeddings.float().to(device)
                    input_embeddings_lengths_batch = torch.stack([torch.tensor(a.clone().detach()) for a in input_raw_embeddings_lengths], 0).to(device)
                    input_masks_batch = torch.stack(input_masks, 0).to(device)
                    input_mask_invert_batch = torch.stack(input_mask_invert, 0).to(device)
                    target_ids_batch = torch.stack(target_ids, 0).to(device)
                    word_contents_batch = torch.stack(word_contents, 0).to(device)
                    word_contents_attn_batch = torch.stack(word_contents_attn, 0).to(device)

                    # Zero the parameter gradients
                    optimizer.zero_grad()

                    # Forward pass for CNN, LSTM, and Random Forest (not used in deep learning)
                    if isinstance(model, CNNModel):
                        logits = model(input_embeddings_batch)  # CNN Forward
                    elif isinstance(model, LSTMModel):
                        logits = model(input_embeddings_batch)  # LSTM Forward
                    elif isinstance(model, RandomForestClassifier):
                        logits = evaluate_random_forest(model, input_embeddings_batch.cpu().detach().numpy())  # Random Forest Forward
                    else:
                        raise ValueError('Unsupported model type.')

                    # Calculate loss for CNN, LSTM, and Random Forest
                    if isinstance(model, (CNNModel, LSTMModel)):
                        loss = criterion(logits, target_ids_batch)
                    else:
                        loss = torch.tensor(0.0).to(device)  # No loss for Random Forest during training loop

                    # Backward + optimize only if in training phase
                    if phase == 'train' and isinstance(model, (CNNModel, LSTMModel)):
                        loss.backward()
                        optimizer.step()

                    running_loss += loss.item() * input_embeddings_batch.size()[0]  # batch loss
                    tepoch.set_postfix(loss=loss.item(), lr=scheduler.get_lr())

                    # TensorBoard logging
                    if phase == 'train':
                        train_writer.add_scalar("train_full", loss.item(), index_plot)
                        index_plot += 1
                    if phase == 'dev':
                        dev_writer.add_scalar("dev_full", loss.item(), index_plot_dev)
                        index_plot_dev += 1

            epoch_loss = running_loss / dataset_sizes[phase]
            if phase == 'train':
                train_losses.append(epoch_loss)
                torch.save(model.state_dict(), checkpoint_path_last)
            elif phase == 'dev':
                val_losses.append(epoch_loss)

            if phase == 'train':
                train_losses.append(epoch_loss)
                train_writer.add_scalar("train", epoch_loss, epoch)
            elif phase == 'dev':
                val_losses.append(epoch_loss)
                train_writer.add_scalar("val", epoch_loss, epoch)

            print(f'{phase} Loss: {epoch_loss:.4f}')

            # Deep copy the model
            if phase == 'dev' and epoch_loss < best_loss:
                best_loss = epoch_loss
                torch.save(model.state_dict(), checkpoint_path_best)
                print(f'Update best on dev checkpoint: {checkpoint_path_best}')

        print()

    print(f"Train losses: {train_losses}")
    print(f"Val losses: {val_losses}")

    time_elapsed = time.time() - since
    print(f'Training complete in {time_elapsed // 60:.0f}m {time_elapsed % 60:.0f}s')
    print(f'Best val loss: {best_loss:.4f}')
    torch.save(model.state_dict(), checkpoint_path_last)
    print(f'Update last checkpoint: {checkpoint_path_last}')

    return model


if __name__ == '__main__':
    args = get_config('train_decoding')
    dataset_setting = 'unique_sent'
    model_name = args['model_name']

    # Initialize model (Choose CNN, LSTM, or Random Forest based on your selection)
    if model_name == 'CNN':
        model = CNNModel(input_channels=3, num_classes=10)  # Adjust num_classes based on the problem
    elif model_name == 'LSTM':
        model = LSTMModel(input_size=128, hidden_size=128, num_layers=2, num_classes=10)
    elif model_name == 'RandomForest':
        model = train_random_forest(train_data, train_labels)  # Assuming `train_data` and `train_labels` are defined
    else:
        raise ValueError('Unsupported model name.')

    # Setup other parts of the pipeline (dataset, loss function, optimizer, etc.)
    # ...
    train_model(dataloaders, device, model, criterion, optimizer, scheduler)
