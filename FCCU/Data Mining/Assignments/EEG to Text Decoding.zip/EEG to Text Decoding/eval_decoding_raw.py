from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import numpy as np

def eval_model(dataloaders, device, tokenizer, criterion, model, output_all_results_path='./results_raw/temp.txt'):
    # modified from: https://pytorch.org/tutorials/beginner/transfer_learning_tutorial.html

    gpt = False
    print("Saving to: ", output_all_results_path)
    model.eval()  # Set model to evaluation mode
    running_loss = 0.0

    # Initialize lists for predictions and true values
    true_labels = []
    pred_labels = []
    
    sample_count = 0
    target_tokens_list = []
    target_string_list = []
    pred_tokens_list = []
    pred_string_list = []
    refine_tokens_list = []
    refine_string_list = []

    with open(output_all_results_path, 'w') as f:
        for _, seq_len, input_masks, input_mask_invert, target_ids, target_mask, sentiment_labels, sent_level_EEG, input_raw_embeddings, input_raw_embeddings_lengths, word_contents, word_contents_attn, subject_batch in dataloaders['test']:

            # Load in batch
            input_embeddings_batch = input_raw_embeddings.to(device).float()
            input_embeddings_lengths_batch = torch.stack([torch.tensor(a.clone().detach()) for a in input_raw_embeddings_lengths], 0).to(device)
            input_masks_batch = torch.stack(input_masks, 0).to(device)
            input_mask_invert_batch = torch.stack(input_mask_invert, 0).to(device)
            target_ids_batch = torch.stack(target_ids, 0).to(device)
            word_contents_batch = torch.stack(word_contents, 0).to(device)
            word_contents_attn_batch = torch.stack(word_contents_attn, 0).to(device)
            subject_batch = np.array(subject_batch)
                        
            target_tokens = tokenizer.convert_ids_to_tokens(target_ids_batch[0].tolist(), skip_special_tokens=True)
            target_string = tokenizer.decode(target_ids_batch[0], skip_special_tokens=True)

            f.write(f'target string: {target_string}\n')
            target_tokens_string = "["
            for el in target_tokens:
                target_tokens_string = target_tokens_string + str(el) + " "
            target_tokens_string += "]"
            f.write(f'target tokens: {target_tokens_string}\n')

            # Add to list for later calculating BLEU metric
            target_tokens_list.append([target_tokens])
            target_string_list.append(target_string)
            
            # Replace padding ids in target_ids with -100
            target_ids_batch[target_ids_batch == tokenizer.pad_token_id] = -100 

            # Forward pass
            seq2seqLMoutput = model(
                input_embeddings_batch, input_masks_batch, input_mask_invert_batch, target_ids_batch, input_embeddings_lengths_batch, word_contents_batch, word_contents_attn_batch, False, subject_batch, device)

            # Calculate loss
            loss = criterion(seq2seqLMoutput.permute(0, 2, 1), target_ids_batch.long())

            # Get predicted tokens
            logits = seq2seqLMoutput
            probs = logits[0].softmax(dim=1)
            values, predictions = probs.topk(1)
            predictions = torch.squeeze(predictions)
            predicted_string = tokenizer.decode(predictions).split('</s></s>')[0].replace('<s>', '')

            f.write(f'predicted string: {predicted_string}\n')
            
            # Convert to int list
            predictions = predictions.tolist()
            truncated_prediction = []
            for t in predictions:
                if t != tokenizer.eos_token_id:
                    truncated_prediction.append(t)
                else:
                    break
            pred_tokens = tokenizer.convert_ids_to_tokens(truncated_prediction, skip_special_tokens=True)
            pred_tokens_list.append(pred_tokens)
            pred_string_list.append(predicted_string)

            # ChatGPT refinement and tokenizer decode
            if gpt:
                predicted_string_chatgpt = chatgpt_refinement(predicted_string).replace('\n', '')
                f.write(f'refined string: {predicted_string_chatgpt}\n')
                refine_tokens_list.append(tokenizer.convert_ids_to_tokens(tokenizer(predicted_string_chatgpt)['input_ids'], skip_special_tokens=True))
                refine_string_list.append(predicted_string_chatgpt)

            pred_tokens_string = "["
            for el in pred_tokens:
                pred_tokens_string = pred_tokens_string + str(el) + " "
            pred_tokens_string += "]"
            f.write(f'predicted tokens (truncated): {pred_tokens_string}\n')
            f.write(f'################################################\n\n\n')

            sample_count += 1
            # Statistics
            running_loss += loss.item() * input_embeddings_batch.size()[0]  # batch loss
            
            # Collect true labels and predicted labels for metrics
            true_labels.extend(target_ids_batch.cpu().numpy())
            pred_labels.extend(predictions.cpu().numpy())

    epoch_loss = running_loss / dataset_sizes['test_set']
    print('Test loss: {:4f}'.format(epoch_loss))

    # Calculate accuracy, precision, recall, F1 score
    accuracy = accuracy_score(true_labels, pred_labels)
    precision = precision_score(true_labels, pred_labels, average='macro', zero_division=0)
    recall = recall_score(true_labels, pred_labels, average='macro', zero_division=0)
    f1 = f1_score(true_labels, pred_labels, average='macro', zero_division=0)

    # Print metrics
    print(f'Accuracy: {accuracy:.4f}')
    print(f'Precision: {precision:.4f}')
    print(f'Recall: {recall:.4f}')
    print(f'F1 Score: {f1:.4f}')

    # Calculate AUC (Area Under the Curve) - assuming binary classification or multi-class classification
    try:
        auc = roc_auc_score(true_labels, pred_labels, multi_class='ovr', average='macro')
        print(f'AUC: {auc:.4f}')
    except ValueError:
        print('AUC cannot be computed for this task')

    print("Predicted outputs")

    # Calculate BLEU score
    weights_list = [(1.0, ), (0.5, 0.5), (1./3., 1./3., 1./3.), (0.25, 0.25, 0.25, 0.25)]
    for weight in weights_list:
        corpus_bleu_score = corpus_bleu(target_tokens_list, pred_tokens_list, weights=weight)
        print(f'Corpus BLEU-{len(list(weight))} score:', corpus_bleu_score)
    print()

    # Calculate ROUGE score
    rouge = Rouge()
    rouge_scores = rouge.get_scores(pred_string_list, target_string_list, avg=True)
    print(rouge_scores)
    print()

    # Calculate BERTScore
    from bert_score import score
    P, R, F1 = score(pred_string_list, target_string_list, lang='en', device="cuda:0", model_type="bert-large-uncased")
    print(f"BERScore P: {np.mean(np.array(P))}")
    print(f"BERScore R: {np.mean(np.array(R))}")
    print(f"BERScore F1: {np.mean(np.array(F1))}")
    print("*************************************")

    if gpt:
        print("Refined outputs with GPT4")
        # Calculate BLEU score for refined outputs
        for weight in weights_list:
            corpus_bleu_score = corpus_bleu(target_tokens_list, refine_tokens_list, weights=weight)
            print(f'Corpus BLEU-{len(list(weight))} score:', corpus_bleu_score)
        print()
        # Calculate ROUGE score for refined outputs
        rouge_scores = rouge.get_scores(refine_string_list, target_string_list, avg=True)
        print(rouge_scores)
        print()
        # Calculate BERTScore for refined outputs
        P, R, F1 = score(refine_string_list, target_string_list, lang='en', device="cuda:0", model_type="bert-large-uncased")
        print(f"BERScore P: {np.mean(np.array(P))}")
        print(f"BERScore R: {np.mean(np.array(R))}")
        print(f"BERScore F1: {np.mean(np.array(F1))}")
        print("*************************************")
        print("*************************************")
