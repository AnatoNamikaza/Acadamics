#include <omp.h>
#include "Helper.h"

using namespace std;

int S_value = -99999999, S_Count = 0, ** Matrix_;

int Search_count(int s_val, int id, int len)
{
    int j = 0, count = 0;
    do
    {
        if (Matrix_[id][j] == s_val)
            count++;
        j++;
    } while (j < len);

    return count;
}

int main()
{
    std::string filename = "Matrix.txt";

    int* order = Matrix_File_Order(filename);
    int i = 0;
    Matrix_ = new int* [order[0]];
    for (; i < order[0]; i++)
        Matrix_[i] = new int[order[1]]{ 0 };

    Matrix_File_Filler(filename, Matrix_);
    std::cout << "============================================================" << std::endl;
    std::cout << "Matrix: " << std::endl << std::endl;
    Matrix_Print(Matrix_, order[0], order[1]);
    std::cout << "============================================================" << std::endl;
    std::cout << "Enter value to search in Matrix: ";
    std::cin >> S_value;
    std::cout << "============================================================" << std::endl;

    #pragma omp parallel
    {
        #pragma omp for
        for (int i = 0; i < order[0]; i++)
        {
            int Id = omp_get_thread_num(), r_Count = 0;

            #pragma omp task
            {
                r_Count = Search_count(S_value, Id, order[1]);

                #pragma omp critical
                S_Count += r_Count;
            }
        }
    }

    for (i = 0; i < order[0]; i++)
        delete[] Matrix_[i], Matrix_[i] = nullptr;
    delete[] Matrix_, Matrix_ = nullptr;

    delete[] order;

    std::cout << "Value searched in Matrix: " << S_value << std::endl;
    std::cout << "No. of occurance in Matrix: " << S_Count << std::endl;

    std::cout << "============================================================" << std::endl;

    return 0;
}
