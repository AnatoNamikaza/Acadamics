#include <cmath>
#include <string>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <stdlib.h>

int* Matrix_File_Order(std::string filename)
{

    std::ifstream fin(filename);

    if (!fin.is_open())
    {
        std::cout << "File " << filename << " is not accessable or doesnot exist." << '\n';
        return nullptr;
    }

    int row = 0, col = 0, prevCol = 0;
    std::string line, val;

    while (getline(fin, line))
    {
        col = 0;
        std::stringstream m_E;
        m_E << line;
        while (m_E >> val) col++;

        if (prevCol == 0) prevCol = col;
        else if (prevCol != col)
        {
            std::cout << "Matrix Order irregularity detected in File " << filename << ".\n";
            break;
        }
        row++;
    }

    fin.close();
    int* Matrix_Orders = new int[2];
    Matrix_Orders[0] = row, Matrix_Orders[1] = col;
    return Matrix_Orders;
};

void Matrix_Print(int** Matrix, int& rows, int& cols)
{
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
            std::cout << Matrix[i][j] << '\t';
        std::cout << '\n';
    }
}

void Matrix_File_Filler(std::string& filename, int** Matrix)
{
    std::ifstream fin(filename);

    if (!fin.is_open())
    {
        std::cout << "File " << filename << " is not accessable or doesnot exist." << '\n';
        return;
    }

    int row = 0, col;
    std::string line, val;

    while (getline(fin, line))
    {
        std::stringstream m_E;
        m_E << line;
        val = "";
        col = 0;
        while (m_E >> val)
            Matrix[row][col] = stoi(val),
            col++;
        row++;
    }

    fin.close();
}
