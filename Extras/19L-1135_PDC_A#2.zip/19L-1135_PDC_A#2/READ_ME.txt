For compiling Q1:
	g++ -o Q1.exe -fopenmp Q1.cpp Helper.h
	./Q1.exe

For compiling Q2:
	g++ -o Q2.exe -fopenmp Q2.cpp Helper.h
	./Q2.exe

For Master Run:
	./make