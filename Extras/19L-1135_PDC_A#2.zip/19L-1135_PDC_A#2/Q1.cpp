#include <omp.h>
#include "Helper.h"

using namespace std;

int P_Max = -99999999, P_Count = 0;

bool isPrime(double val)
{
    double n = 1, i = 2, m = log2(val);
    while (i <= m)
    {
        if (std::fmod(val, i) == 0)
            n++;
        i++;
    }

    return (n == 1 ? true : false);
}

int main()
{
    std::string filename = "Matrix.txt";

    int* order = Matrix_File_Order(filename);
    int i = 0, ** Matrix_ = new int* [order[0]];
    for (; i < order[0]; i++)
        Matrix_[i] = new int[order[1]]{ 0 };

    Matrix_File_Filler(filename, Matrix_);
    std::cout << "============================================================" << std::endl;
    std::cout << "Matrix: " << std::endl << std::endl;
    Matrix_Print(Matrix_, order[0], order[1]);
    std::cout << "============================================================" << std::endl;
    
    int numt;

    #pragma omp parallel num_threads(order[0])
    {
        numt = omp_get_num_threads();
        int Id = omp_get_thread_num(), tempCount = 0, tempMax = -99999999, i = 0;
        do
        {
            if (isPrime(Matrix_[Id][i]))
                tempCount++;

            if (tempMax < Matrix_[Id][i])
                tempMax = Matrix_[Id][i];
            i++;
        } while (i < order[1]);

        #pragma omp critical
        {
            if (tempMax > P_Max)
            {
                P_Max = tempMax;
            }

            P_Count += tempCount;
        }
    }

    for (i = 0; i < order[0]; i++)
        delete[] Matrix_[i], Matrix_[i] = nullptr;
    delete[] Matrix_, Matrix_ = nullptr;

    delete[] order;

    std::cout << "Thread created: " << numt << std::endl;
    std::cout << "Prime No's in Matrix: " << P_Count << std::endl;
    std::cout << "Max Value in Matrix: " << P_Max << std::endl;

    std::cout << "============================================================" << std::endl;

    return 0;
}
