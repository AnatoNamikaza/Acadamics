#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

using namespace std;

int rows, cols, gMax = -99999999, gCount = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

bool isPrime(int val)
{
    int n = 0, i = 1;
    do
    {
        if (val % i == 0)
            n++;
        i++;
    } while (i <= (val / 2));

    return (n == 1 ? true : false);
}

void* myFun(void* param)
{
    int* row = (int*)param;
    int tempCount = 0, tempMax = -99999999, i = 0;
    do
    {
        if (isPrime(row[i]))
            tempCount++;
        if (tempMax < row[i])
            tempMax = row[i];
        i++;
    } while (i < cols);

    pthread_mutex_lock(&mutex);
    gCount += tempCount;

    if (tempMax > gMax)
    {
        gMax = tempMax;
    }

    pthread_mutex_unlock(&mutex);
    pthread_exit(0);
}

int main()
{
    int** matrix = nullptr;
    cout << "Enter no. of Rows in Matrix: \n";
    cin >> rows;
    cout << "Enter no. of cols in Matrix: \n";
    cin >> cols;
    cout << endl;

    matrix = new int* [rows];
    int i = 0, j = 0;
    do
    {
        matrix[i] = new int[cols];
        j = 0;
        do
        {
            cout << "Enter row#" << i << ", col#" << j << " value: ";
            cin >> matrix[i][j];
            cout << endl;
            j++;
        } while (j < cols);
        i++;
    } while (i < rows);

    cout << "============================================================" << endl;
    cout << "Matrix: " << endl << endl;

    i = 0;
    do
    {
        j = 0;
        do
        {
            cout << matrix[i][j];
            if (j < cols - 1)
                cout << ", ";
            j++;
        } while (j < cols);
        cout << endl;
        i++;
    } while (i < rows);
    cout << endl;

    pthread_t thread[rows];

    i = 0;
    do
    {
        if (pthread_create(&thread[i], NULL, myFun, (void*)matrix[i]) != 0)
        {
            cout << "[ERROR] Thread Creation Failed\nProgram Ending" << endl;
            exit(-1);
        }
        i++;
    } while (i < rows);

    i = 0;
    do
    {
        pthread_join(thread[i], NULL);
        i++;
    } while (i < rows);


    cout << endl << "Prime No's in Matrix: " << gCount << endl;
    cout << "Max Value in Matrix: " << gMax << endl;
    return 0;
}
