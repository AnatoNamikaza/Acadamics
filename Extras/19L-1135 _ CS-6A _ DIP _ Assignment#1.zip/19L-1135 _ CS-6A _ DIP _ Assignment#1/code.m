clc
clear
close

a = imread('source.png');
b = imread('source.png');
s = size(a);

equalized = zeros(1,256);
for i = 1:s(1)
    for j = 1:s(2)
        equalized(a(i,j)+1)=equalized(a(i,j)+1)+1;
    end
end

for i=1:256
    equalized(i)=equalized(i)/(s(1)*s(2));
end

for i =2:256
   equalized(i)=equalized(i-1)+equalized(i); 
end

for i=1:256
    equalized(i)=round(equalized(i)*255);
end



for i = 1:s(1)
    for j = 1:s(2)
        b(i,j)=equalized(b(i,j));
    end
end
subplot(2,1,1);
imshow(a);

subplot(2,1,2);
imshow(b);





